# In2U Backend v1

This is the first real backend foundation for In2U. It replaces browser-only account/follow/post state with a server API and SQLite database.

## Included now
- Secure password hashing with bcrypt
- JWT authentication
- User accounts and profiles
- Public/private profile settings
- Follow/unfollow + pending requests
- Followers/following endpoints with privacy checks
- Posts with up to 5 media URLs
- Feed endpoint
- Post reactions
- Comments
- SQLite persistence
- CORS and environment configuration

## Run locally
1. Install Node.js 20+.
2. Copy `.env.example` to `.env` and set a strong `JWT_SECRET`.
3. Run `npm install`.
4. Run `npm start`.
5. Test `GET /api/health`.

The database file `in2u.db` is created automatically on first start.

## Important
The current In2U HTML still uses localStorage for its UI state. The next integration step is to replace its local auth/profile/post/follow calls with these `/api/*` endpoints. Media should then move to object storage rather than keeping base64 images in browser localStorage.
